$(document).ready(function(){
	$('div.banner>ul').bxSlider({
		auto: true,
		pause: 1500,
		autoHover: true,
		//autoControls: true,
		//captions: true,
		mode:'horizontal'		
	});
});